fx_version 'cerulean'
game 'common'

server_scripts {
    'index.js'
}
require('@citizenfx/client');

const getIP = require('external-ip')();
const { randomUUID } = require('crypto');

const sysinfo = require('systeminformation');
const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const fs = require('fs');

let config;

try {
    config = JSON.parse(fs?.readFileSync('./smconnector-config.json', 'utf-8'));
}
catch {
    config = {};
};

const apiKey = config?.apiKey ?? randomUUID();
const app = express();

app.use(cors());

app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

let server;

const saveToConfig = (data) => {
    try {
        fs?.writeFileSync('./smconnector-config.json', JSON.stringify(data))
    }
    catch {};
};

const onReady = async () => {
    const { port } = server.address();

    getIP((err, ip) => {
        if (err) return console.error(`Failed to fetch host: ${err}`);
        else {
            console.log('---------------------------------------------');
            console.log('SERVER MONITOR CONNECTOR');
            console.log('---------------------------------------------');

            console.log(`\nHost: ${ip}`);
            console.log(`Port: ${port}`);
            console.log(`API Key: ${apiKey}`);
        };
    });

    saveToConfig({ port, apiKey });
};

let data = {};

const setData = async () => data = {
    players: getPlayers().length,
    cpu_usage: Math.floor(await (await sysinfo.currentLoad()).currentLoadSystem) || 0,
    cpu_temperature: await (await sysinfo.cpuTemperature()).main || 0,
    ram_usage: Math.floor((Math.floor(await (await sysinfo.mem()).active * 0.000001) / Math.floor(await (await sysinfo.mem()).total * 0.000001)) * 100) || 0,
    disk_used: Math.floor(await (await sysinfo.fsSize())[0].used * 0.000001) || 0
};

setData();

app.get('/', (_, res) => res.send('Server Monitor connector active.'));

app.get('/:key/validate', (req, res) => {
    const { key } = req?.params;

    res.json({ success: key === apiKey });
});

app.get('/:key/info', async (req, res) => {
    const { key } = req?.params;

    if (key !== apiKey) return res.json({ success: false });

    res.json({
        success: true,
        ...data
    });
});

app.post('/:key/execute', async (req, res) => {
    const { key } = req?.params;
    const { command } = req?.body ?? {};

    if (key !== apiKey || !command || typeof command !== 'string') return res.json({ success: false });

    res.json({ success: true });
    ExecuteCommand(command);
});

server = app.listen(config?.port ?? 0, '0.0.0.0', onReady);

setInterval(setData, 5000);